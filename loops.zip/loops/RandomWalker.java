public class RandomWalker {
    public static void main(String[] args) {
        int r = Integer.parseInt(args[0]);

        int x = 0;
        int y = 0;

        System.out.println("(" + x + ", " + y + ")");

        while (Math.abs(x) + Math.abs(y) < r) {
            int dir = (int) (4 * Math.random());

            if (dir == 0) {
                y++;
            } else if (dir == 1) {
                y--;
            } else if (dir == 2) {
                x++;
            } else {
                x--;
            }

            System.out.println("(" + x + ", " + y + ")");
        }

        System.out.println("steps = " + (Math.abs(x) + Math.abs(y)));
    }
}
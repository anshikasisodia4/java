
public class RandomWalkers {
    public static void main(String[] args) {
        int r = Integer.parseInt(args[0]);
        int trials = Integer.parseInt(args[1]);

        long totalSteps = 0;

        for (int t = 0; t < trials; t++) {
            int x = 0;
            int y = 0;
            int steps = 0;

            while (Math.abs(x) + Math.abs(y) < r) {
                int dir = (int) (4 * Math.random());

                if (dir == 0) {
                    y++;
                } else if (dir == 1) {
                    y--;
                } else if (dir == 2) {
                    x++;
                } else {
                    x--;
                }

                steps++;
            }

            totalSteps += steps;
        }

        System.out.println("average number of steps = "
                           + (double) totalSteps / trials);
    }
}